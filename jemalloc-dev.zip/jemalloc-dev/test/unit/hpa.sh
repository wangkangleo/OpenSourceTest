#!/bin/sh

export MALLOC_CONF="process_madvise_max_batch:0"
