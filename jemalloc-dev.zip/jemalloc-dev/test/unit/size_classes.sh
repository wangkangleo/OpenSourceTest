#!/bin/sh

export MALLOC_CONF="disable_large_size_classes:true"
